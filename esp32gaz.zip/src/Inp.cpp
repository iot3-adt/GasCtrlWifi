#include "Inp.h"
//----------------
bool Inp::getValue(int* ar, int sizeAr){
  ar[0] = 10;
  ar[1] = 20;
  ar[2] = 30;
  ar[3] = 40;
  ar[4] = 50;
  return true;
}
