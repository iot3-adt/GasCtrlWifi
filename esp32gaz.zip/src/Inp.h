#ifndef INP_H
#define INP_H
class Inp {
  public:
  bool getValue(int* ar, int sizeAr);
  
};
#endif
